# alf-code-node-validator

채널톡 ALF(FrontALF) Code node용 JavaScript 코드가 공식 문서의 제약을 지키는지 검증하는 Codex 플러그인.

## 1. 문제

채널톡 ALF Code node는 [공식 문서](https://developers.channel.io/en/articles/Code-node-fdcd71b4)에 아래 제약을 명문화하고 있다.

- JavaScript 전용
- 실행 60초 제한
- HTTP 요청은 axios 전용
- `require`는 `axios`·`crypto`만 허용
- 금지 함수: `process`/`global`/`Buffer`/`eval`/`Function`/`setTimeout`/`setInterval`/`clearTimeout`/`clearInterval`/`setImmediate`/`clearImmediate`
- `isSandbox=true`면 axios 외부 네트워크 요청 차단
- `memory.put()` 후 `memory.save()` 필수(안 하면 저장 안 됨)
- 함수 시그니처는 `(memory, context[, isSandbox])` 순서

이 제약을 어겨도 코드는 문법적으로 멀쩡해서 작성 시점엔 에러가 나지 않는다. 배포 후 조용히 실패하거나(예: `memory.save()` 누락으로 데이터 유실), 샌드박스 테스트는 통과했는데 실제 대화에서만 깨지는(`isSandbox` 분기 오작성) 식으로 드러난다.

## 2. 이 플러그인이 하는 일

Code node용 JS 코드를 받아 아래 R1~R6 규칙으로 검증하고, 위반마다 다음 4항목으로 리포트한다.

- 무엇이
- 왜 위반
- references 근거 문장 (문서 원문 그대로 인용)
- 수정안

| 규칙 | 내용 |
|---|---|
| R1 | 언어 = JavaScript인가 |
| R2 | 60초 안에 끝날 구조인가 |
| R3 | 금지 함수·라이브러리를 사용하지 않는가 |
| R4 | isSandbox 분기에서 외부 네트워크 호출을 안 하는가 |
| R5 | `memory.put()` 뒤 `memory.save()`가 있는가 |
| R6 | 함수 시그니처(인자 순서)가 올바른가 |

각 규칙은 `위반` / `위반 없음` / `확인 불가` / `해당 규칙 대상 아님` 네 가지 상태 중 하나로 표기된다.

## 3. 이중 검증 구조 (작동 방식과 폴백)

이 플러그인은 두 계층으로 동작한다.

**1차 — 보조 정적 스크립트** (`src/scripts/validate_code_node.py`)
자동으로 텍스트 패턴만 매칭한다.
- 잡는 것: `fetch(` 사용(R3 일부), isSandbox 분기 내부 http 호출(R4), `memory.put(` 뒤 `memory.save(` 없음(R5, **파일 전체 기준**), `while(true)`/`for(;;)`/대량 반복 상수(R2 일부)
- 안 잡는 것: R1(언어 판별), R3의 금지 함수 전체 목록, R6(인자 순서), 분기별 `memory.save` 누락

**2차 — SKILL(`verify-alf-code-node`)의 R1~R6 수동 검사**
스크립트가 아예 다루지 않는 부분(R1·R3 전체·R6)과, 스크립트가 구조적으로 놓치는 부분(분기별 `save` 누락)을 references 문서와 직접 대조해 채운다. 스크립트 결과는 참고용 1차 스캔일 뿐이고, 최종 리포트는 반드시 이 수동 절차로 작성한다.

**폴백 — 정보가 부족하거나 판단이 서지 않을 때**
- `references/code-node-constraints.md`에 근거 문장이 없는 사안은 위반으로 단정하지 않고 "문서 근거 없음 — 확인 불가"라고만 답한다. 채널톡 API·제약을 지어내지 않는다.
- 정적으로 판단할 수 없는 것(예: 실제 실행 시간)은 위반으로 단정하지 않고 `확인 불가`로 표기한다.
- 규칙 자체가 해당하지 않는 코드(예: `isSandbox` 분기가 없는 코드에 대한 R4)는 `해당 규칙 대상 아님`으로 표기해 `위반 없음`과 구분한다.
- R1~R6과 무관한 코드 스타일·품질 문제는 지적하지 않는다 — 범위는 6개 규칙 준수 여부뿐이다.

## 4. 설치·사용법

저장소 루트에서 Codex 로컬 마켓플레이스 등록:
```
codex plugin marketplace add ./
```

Codex 실행 후 플러그인 설치:
```
/plugins
```
목록에서 `alf-code-node-validator`를 찾아 설치한다.

호출:
```
@verify-alf-code-node
```
로 검사할 Code node JS 코드(파일 경로 또는 붙여넣기)를 전달한다.

## 5. 검증 예시

`tests/results.md`에 실제 실행 로그 전체가 있다. 요약:

| 케이스 | 자동검사(스크립트) | 수동검사(R1~R6) | 확인된 것 |
|---|---|---|---|
| `tests/pass_example.js` (공식 isSandbox 예시 기반) | 0건 | 전 규칙 위반 없음 | 정상 코드에서 자동·수동 모두 오탐 없음 |
| `tests/fail_script_example.js` | 4건 (R2·R3·R4·R5) | 동일하게 R2·R3·R4·R5 위반 | 스크립트가 잡아야 할 위반을 놓치지 않음 |
| `tests/fail_manual_example.js` | **0건** | **R3(setTimeout)·R5(분기별 save 누락)·R6(인자 순서) 3건 위반** | 자동검사만으로는 놓치는 위반을 수동 R1~R6이 보완 |
| 문서에 없는 함수(`someInternalHelper`) 포함 코드 ※ | — | "공식 문서에 근거 없어 판단하지 않음" | 폴백 규칙이 위반 단정·규칙 날조 없이 정직하게 동작 |

※ 폴백 사례는 Codex CLI 로컬 실행(D-005 기록)에서 실제로 관측된 결과다. 위 세 케이스(`pass_example.js`/`fail_script_example.js`/`fail_manual_example.js`)는 이 저장소 안에서 스크립트를 직접 재실행해 확인한 것이고, 폴백 사례는 그와 동일 세션이 아닌 별도의 Codex 실행에서 나온 결과다. 추정이나 예상이 아니라 실제 실행에서 관측된 동작이다.

`fail_manual_example.js`가 이 플러그인의 설계 의도를 가장 잘 보여준다: 자동검사는 "0건 발견"으로 통과처럼 보이지만, 수동 R1~R6이 `setTimeout` 사용(금지 함수), `memory.save` 분기별 누락, 인자 순서 `(context, memory)` 뒤바뀜을 정확히 잡아낸다.

## 6. 한계

- 정적 분석만으로는 실제 실행 시간(60초 초과 여부)을 단정할 수 없다. 런타임에서만 확정 가능하므로 애매한 구조는 위반 단정 대신 `확인 불가`로 표기한다.
- 4가지 자동 검사는 텍스트/정규식 패턴 매칭이라 주석이나 문자열 리터럴 안의 키워드도 실제 코드와 구분하지 못하고 매칭될 수 있다(오탐 가능). 실제로 테스트 파일 작성 중 주석에 적어둔 `while(true)`라는 문구가 오탐으로 잡힌 적이 있다.
- 스크립트의 `memory.save` 검사는 분기 단위가 아니라 파일 전체 기준이다. 파일 어딘가에 `save()`가 하나라도 있으면 다른 분기의 누락을 놓친다 — 이 부분은 반드시 수동 R5 검사로 분기별 확인이 필요하다.
- R1(언어 판별), R3의 금지 함수 전체 목록(`process`/`global`/`Buffer`/`eval`/`Function`/`setTimeout`/`setInterval`/`clearTimeout`/`clearInterval`/`setImmediate`/`clearImmediate`, `XMLHttpRequest` 포함), R6(함수 시그니처 인자 순서)은 스크립트가 검사하지 않고 SKILL의 수동 절차에서만 확인한다.

## 참고

- 근거 문서: `src/skills/verify-alf-code-node/references/code-node-constraints.md`
- 검증 절차: `src/skills/verify-alf-code-node/SKILL.md`
- 보조 스크립트: `src/scripts/validate_code_node.py`
- 테스트/실행 로그: `tests/results.md`
- 개발 경위·의사결정 기록: `docs/decisions.md`
